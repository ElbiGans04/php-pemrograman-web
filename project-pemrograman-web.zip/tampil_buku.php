<?php

include 'header.php';

require 'functions.php';
$buku = tampilData("buku");

?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">HALAMAN BUKU</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Halaman Buku</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Daftar Mahasiswa</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <a href="tambah_buku.php" class="btn btn-block btn-primary"> Tambah Data Buku </a>
              <table id="example1" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Judul buku</th>
                    <th>Isbn</th>
                    <th>Penerbit</th>
                    <tr></tr>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $i = 1;
                  foreach ($buku as $rows) :
                  ?>
                    <tr>
                      <th scope="row"><?= $i; ?></th>
                      <td><?= $rows["judul_buku"]; ?></td>
                      <td><?= $rows["isbn"]; ?></td>
                      <td><?= $rows["stok"]; ?></td>
                      <td>
                      <a href="/project-pemrograman-web/detail_buku.php?kode=<?= $rows['kode_buku'] ?>" class="btn btn-primary btn-xs">Tampilkan</a>
                      <a href="/project-pemrograman-web/ubah_buku.php?kode=<?= $rows['kode_buku'] ?>" class="btn btn-warning btn-xs">Ubah</a>
                      <a href="/project-pemrograman-web/delete_buku.php?kode=<?= $rows['kode_buku'] ?>" class="btn btn-danger btn-xs">Hapus</a>
                      </td>
                    </tr>
                  <?php
                    $i++;
                  endforeach;
                  ?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php

include 'footer.php';

?>