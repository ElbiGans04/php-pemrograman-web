<?php

include 'header.php';

require 'functions.php';
$data = detailData("buku", "kode_buku", $_GET['kode']);
if (isset($_POST["submit"])) {
  if (ubah($_POST, "buku")) {
    echo "<script>alert('Data berhasil diubah !!'); window.location = 'tampil_buku.php'</script>";
  } else {
    echo "<script>alert('Data gagal diubah !!'); ";
  }
}

?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">HALAMAN BUKU</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Halaman Buku</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Tambah Buku</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <?php 
                if (isset($data[0])) :
              ?>
              <form action="" method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="kode_buku">Judul Buku</label>
                    <input value="<?= $data[0]['kode_buku'] ?>" type="text" class="form-control" id="kode_buku" name="kode_buku" autocomplete="off" placeholder="e.g laskar pelangi" required>
                  </div>

                  <div class="form-group">
                    <label for="judul_buku">Judul Buku</label>
                    <input value="<?= $data[0]['judul_buku'] ?>" type="text" class="form-control" id="judul_buku" name="judul_buku" autocomplete="off" placeholder="e.g laskar pelangi" required>
                  </div>

                  <div class="form-group">
                    <label for="isbn">Isbn</label>
                    <input value="<?= $data[0]['isbn'] ?>" type="number" class="form-control" id="isbn" name="isbn" autocomplete="off" placeholder="e.g 2123098278" required>
                  </div>

                  <div class="form-group">
                    <label for="penerbit">Penerbit</label>
                    <input value="<?= $data[0]['penerbit'] ?>" type="text" class="form-control" id="penerbit" name="penerbit" placeholder="e.g Erlangga" autocomplete="off" required>
                  </div>

                  <div class="form-group">
                    <label for="pengarang">Pengarang</label>
                    <input value="<?= $data[0]['pengarang'] ?>" type="text" class="form-control" id="pengarang" name="pengarang" placeholder="e.g Rhafael Bijaksana" autocomplete="off" required>
                  </div>

                  <div class="form-group">
                    <label for="stok">Stok</label>
                    <input value="<?= $data[0]['stok'] ?>" type="number" min="0" class="form-control" id="stok" name="stok" placeholder="e.g 1" autocomplete="off" required>
                  </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                </div>

                <?php 
                  else :
                ?>
                  <h1>Data Buku Not found (UNKNOWN)</h1>

                <?php 
                  endif;
                ?>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php

include 'footer.php';

?>